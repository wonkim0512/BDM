# If you don't have linprog package, please execute the following command.
# install.packages('linprog')
library(linprog)

cvec <- c(29000, 21000, 13000, -10000, -6000, 2000)
amat <- rbind(
  matrix(c(-1, 0, 0, 1, 0, 0,
           -1, -1, 0, 1, 1, 0,
           -1, -1, -1, 1, 1, 1), ncol = 6, byrow = T),
  -diag(6))
bvec <- c(-10, -40, -35, 0, 0, 0, 0, 0, 0)

solveLP(cvec, bvec, amat, maximum = F)