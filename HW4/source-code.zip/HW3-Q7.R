# Load subway.csv file to a data frame
# Use read.table
df <- read.table('subway.csv', header = T, sep = ',')

# (a) What is the average number of passengers of Sinchon station?
# The number should be stored in the variable 'ans_a'.
indices1 <- df[, 'station_name'] == '신촌' & df[, 'line'] == '2호선'
ans_a <- mean(df[indices1, 'get_in'] + df[indices1, 'get_off'])

# (b) Find top 10 subway stations in terms of the avg. number of passengers.
# The list of top 10 subway stations should be stored in the variable 'ans_b'.
# (Hint: you may use sort function like the following codes)

# resolve station name confliction
levels(df$station_name) <- c(levels(df$station_name), '신촌2', '양평5')
df[indices1, 'station_name'] <- '신촌2'
df[indices2, 'station_name'] <- '양평5'

# compute the avg. passengers for each station
stations <- levels(df$station_name)
people <- rep(0, length(stations))
for (i in 1:length(stations)) {
  indices <- df[, 'station_name'] == stations[i]
  people[i] <- mean(df[indices, 'get_in'] + df[indices, 'get_off'])
}

# get top 10 stations
top_10_people <- sort(people, decreasing = T)[1:10]
ans_b <- rep('', 10)
for (i in 1:10) {
  indices <- which(people == top_10_people[i])
  ans_b[i] <- stations[indices]
  if (ans_b[i] == '신촌2') {
    ans_b[i] <- '신촌'
  } else if (ans_b[i] == '양평5') {
    ans_b[i] <- '양평'
  }
}

# (c) Find top 3 subway lines in terms of the average number of passengers.
# The list of top 3 subway lines should be stored in the variable 'ans_c'.
lines <- levels(df$line)
people <- rep(0, length(lines))
for (i in 1:length(lines)) {
  indices <- df$line == lines[i]
  # we use sum function instead of mean function because the number of stations in a line are different from each other line.
  people[i] <- sum(df[indices, 'get_in'] + df[indices, 'get_off'])
}

# get 3 top subway lines
ans_c <- rep('', 3)
top_3_people <- sort(people, decreasing = T)[1:3]
for (i in 1:3) {
  indices <- which(top_3_people[i] == people)
  ans_c[i] <- lines[indices]
}

# (d) Draw scatter plots for the number of passengers of Nakseongdae station and Incheon Int'l Airport station.
indices3 <- df$station_name == '낙성대'
indices4 <- df$station_name == '인천국제공항'
plot(df[indices3, 'get_in'] + df[indices3, 'get_off'], ylab='passengers', xlab='days')
plot(df[indices4, 'get_in'] + df[indices4, 'get_off'], ylab='passengers', xlab='days')