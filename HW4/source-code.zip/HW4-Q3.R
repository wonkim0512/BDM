# If you don't have linprog package, please execute the following command.
# install.packages('linprog')
library(linprog)

amat <- matrix(c(0.5, 0.2, 0.75, 0.2, 0.4, 0.2, -1, 0, 0, 0, -1, 0, 0, 0, -1), byrow = T, ncol = 3)
bvec <- c(1500, 600, -1000, -200, -400)
cvec <- c(18, 29, 25)

solveLP(cvec, bvec, amat, maximum = T)
